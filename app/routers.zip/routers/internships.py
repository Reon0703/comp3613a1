from typing import Annotated

from fastapi import Query, Request
from fastapi.responses import HTMLResponse

from app.dependencies.auth import AuthDep
from app.dependencies.session import SessionDep
from app.repositories.internship import InternshipRepository
from app.services.internship_service import InternshipService
from . import router, templates

@router.get("/internships", response_class=HTMLResponse, name = "browse_internships")
def browse_internships(
    request: Request,
    user: AuthDep,
    db: SessionDep,
    q: Annotated[str | None, Query(max_length=100)] = None,
    page: Annotated[int, Query(ge=1)] = 1,
):
    service = InternshipService(InternshipRepository(db))
    result = service.browse(user, query=q, page=page)
    return templates.TemplateResponse(
        request=request,
        name="student_internships.html",
        context={
            "user": user,
            "result": result,
        },
    )